<script>
	import { store } from '../hooks/auth';
</script>

<main>
	Congratulations {$store[0]} Your account has been successfully created
</main>
