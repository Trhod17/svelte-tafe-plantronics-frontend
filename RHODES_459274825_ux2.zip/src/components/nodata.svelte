<script lang="ts">
	export let page;
</script>

<main lang="en">
	<p class="card-title">This plant has no {page}</p>
</main>
