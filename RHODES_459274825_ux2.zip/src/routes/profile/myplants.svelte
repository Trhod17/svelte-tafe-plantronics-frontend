<script lang='ts'>
import MyPlants from '../../components/myPlants.svelte';
import ProfileTab from '../../components/profiletab.svelte';
</script>

<ProfileTab active={1} />
<MyPlants />