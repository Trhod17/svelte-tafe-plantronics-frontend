# default-template

## 0.0.2-next.0
### Patch Changes



- [chore] upgrade cookie library ([#4592](https://github.com/sveltejs/kit/pull/4592))
