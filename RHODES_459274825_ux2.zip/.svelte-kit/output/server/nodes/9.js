import * as module from '../entries/pages/profile/myplants.svelte.js';

export { module };
export const entry = 'pages/profile/myplants.svelte-4a62c183.js';
export const js = ["pages/profile/myplants.svelte-4a62c183.js","chunks/index-4816ba6f.js","chunks/auth-ba37ac4d.js","chunks/index-79f0eb3b.js","chunks/profiletab-fb2efa12.js"];
export const css = [];
