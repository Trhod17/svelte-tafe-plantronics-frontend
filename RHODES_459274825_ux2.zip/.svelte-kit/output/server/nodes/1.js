import * as module from '../entries/fallbacks/error.svelte.js';

export { module };
export const entry = 'error.svelte-69c52dad.js';
export const js = ["error.svelte-69c52dad.js","chunks/index-4816ba6f.js"];
export const css = [];
