import * as module from '../entries/pages/plants/_slug_.svelte.js';

export { module };
export const entry = 'pages/plants/_slug_.svelte-1fd82e89.js';
export const js = ["pages/plants/_slug_.svelte-1fd82e89.js","chunks/index-4816ba6f.js","chunks/planttab-5ea4695d.js","chunks/auth-ba37ac4d.js","chunks/index-79f0eb3b.js"];
export const css = [];
