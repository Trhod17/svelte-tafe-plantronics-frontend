import * as module from '../entries/pages/plants/soil/_slug_.svelte.js';

export { module };
export const entry = 'pages/plants/soil/_slug_.svelte-ba5a2362.js';
export const js = ["pages/plants/soil/_slug_.svelte-ba5a2362.js","chunks/index-4816ba6f.js","chunks/index-79f0eb3b.js","chunks/planttab-5ea4695d.js","chunks/nodata-32a151d6.js"];
export const css = [];
