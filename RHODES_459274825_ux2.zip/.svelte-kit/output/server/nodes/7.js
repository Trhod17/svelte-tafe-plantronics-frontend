import * as module from '../entries/pages/plants/info/_slug_.svelte.js';

export { module };
export const entry = 'pages/plants/info/_slug_.svelte-b6153b93.js';
export const js = ["pages/plants/info/_slug_.svelte-b6153b93.js","chunks/index-4816ba6f.js","chunks/planttab-5ea4695d.js","chunks/index-79f0eb3b.js","chunks/nodata-32a151d6.js"];
export const css = [];
