import * as module from '../entries/pages/plants/edible/_slug_.svelte.js';

export { module };
export const entry = 'pages/plants/edible/_slug_.svelte-e0cf5471.js';
export const js = ["pages/plants/edible/_slug_.svelte-e0cf5471.js","chunks/index-4816ba6f.js","chunks/index-79f0eb3b.js","chunks/planttab-5ea4695d.js","chunks/nodata-32a151d6.js"];
export const css = [];
