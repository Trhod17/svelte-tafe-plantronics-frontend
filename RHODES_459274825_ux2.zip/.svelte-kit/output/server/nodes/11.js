import * as module from '../entries/pages/register.svelte.js';

export { module };
export const entry = 'pages/register.svelte-3796e068.js';
export const js = ["pages/register.svelte-3796e068.js","chunks/index-4816ba6f.js","chunks/auth-ba37ac4d.js","chunks/index-79f0eb3b.js","chunks/index-a44f789b.js"];
export const css = [];
