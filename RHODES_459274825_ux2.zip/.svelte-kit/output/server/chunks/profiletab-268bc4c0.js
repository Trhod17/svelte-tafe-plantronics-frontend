import { c as create_ssr_component } from "./index-de5ece87.js";
const Profiletab = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { active } = $$props;
  if ($$props.active === void 0 && $$bindings.active && active !== void 0)
    $$bindings.active(active);
  return `<div class="${"tabs bg-primary-focus"}"><a class="${["tab tab-bordered w-1/3 text-primary-content", active == 0 ? "tab-active" : ""].join(" ").trim()}" sveltekit:prefetch href="${"/profile"}">My Profile</a>
	<a class="${["tab tab-bordered w-1/3 text-primary-content", active == 1 ? "tab-active" : ""].join(" ").trim()}" sveltekit:prefetch href="${"/profile/myplants"}">My Plants</a>
	<p class="${[
    "tab tab-bordered w-1/3 text-grey-content disabled",
    active == 2 ? "tab-active" : ""
  ].join(" ").trim()}">Coming Soon</p></div>`;
});
export { Profiletab as P };
