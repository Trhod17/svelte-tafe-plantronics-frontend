import { c as create_ssr_component, e as escape } from "./index-de5ece87.js";
const Planttab = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { slug } = $$props;
  let { active } = $$props;
  if ($$props.slug === void 0 && $$bindings.slug && slug !== void 0)
    $$bindings.slug(slug);
  if ($$props.active === void 0 && $$bindings.active && active !== void 0)
    $$bindings.active(active);
  return `<div class="${"tabs bg-primary-focus"}"><a class="${["tab tab-bordered w-1/3 text-primary-content", active == 0 ? "tab-active" : ""].join(" ").trim()}" sveltekit:prefetch href="${"/plants/" + escape(slug)}">Plant</a>
	<a class="${["tab tab-bordered w-1/3 text-primary-content", active == 1 ? "tab-active" : ""].join(" ").trim()}" sveltekit:prefetch href="${"/plants/info/" + escape(slug)}">Info</a>
	<a class="${["tab tab-bordered w-1/3 text-primary-content", active == 2 ? "tab-active" : ""].join(" ").trim()}" sveltekit:prefetch href="${"/plants/soil/" + escape(slug)}">Soil Preference
	</a>
	<a class="${["tab tab-bordered w-1/3 text-primary-content", active == 3 ? "tab-active" : ""].join(" ").trim()}" sveltekit:prefetch href="${"/plants/edible/" + escape(slug)}">Ediblity</a></div>`;
});
export { Planttab as P };
