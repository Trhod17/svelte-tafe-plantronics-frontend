import { c as create_ssr_component, a as subscribe, v as validate_component, e as escape } from "../../chunks/index-de5ece87.js";
import { s as store } from "../../chunks/auth-68aeceae.js";
import { P as Profiletab } from "../../chunks/profiletab-268bc4c0.js";
import "../../chunks/index-fadab37b.js";
import "axios";
const Profile = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_store;
  $$unsubscribe_store = subscribe(store, (value) => value);
  let { data = [] } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  $$unsubscribe_store();
  return `${validate_component(Profiletab, "ProfileTab").$$render($$result, { active: 0 }, {}, {})}

<div class="${"card border w-9/12 text-base-content "}"><div class="${"card-body whitespace-pre-wrap text-sm break-words"}"><p class="${"card-title"}">My Profile</p>
		<ul>${data != "" ? `<li>Username: ${escape(data.data.attributes.username)}</li>
				<li>First Name: ${escape(data.data.attributes.first_name)}</li>
				<li>Last Name: ${escape(data.data.attributes.last_name)}</li>
				<li>Email: ${escape(data.data.attributes.email)}</li>` : ``}</ul></div></div>`;
});
const prerender = true;
const Profile_1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${$$result.head += `${$$result.title = `<title>Profile</title>`, ""}<meta name="${"description"}" content="${"Svelte demo app"}" data-svelte="svelte-19mfyn7">`, ""}

<main>${validate_component(Profile, "Profile").$$render($$result, {}, {}, {})}
</main>`;
});
export { Profile_1 as default, prerender };
