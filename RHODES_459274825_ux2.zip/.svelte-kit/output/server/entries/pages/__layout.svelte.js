import { c as create_ssr_component, a as subscribe, e as escape, v as validate_component } from "../../chunks/index-de5ece87.js";
import { s as store } from "../../chunks/auth-68aeceae.js";
import "theme-change";
import "../../chunks/index-fadab37b.js";
import "axios";
const Themeswitch = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<div class="${"mb-8"}"><select data-choose-theme class="${"select select-bordered select-primary w-full max-w-3xl text-xl"}"><option disabled="${"disabled"}" selected="${"selected"}" value="${"Theme"}">Theme</option><option value="${"forest"}">Forest (default)</option><option value="${"light"}">Light</option><option value="${"dark"}">Dark</option><option value="${"acid"}">Acid</option><option value="${"autumn"}">Autumn</option><option value="${"bumblebee"}">Bumblebee</option><option value="${"business"}">Business</option><option value="${"coffee"}">Coffee</option><option value="${"corporate"}">Corporate</option><option value="${"cupcake"}">Cupcake</option><option value="${"cyberpunk"}">Cyberpunk</option><option value="${"dracula"}">Dracula</option><option value="${"emerald"}">Emerald</option><option value="${"fantasy"}">Fantasy</option><option value="${"garden"}">Garden</option><option value="${"lemonade"}">Lemonade</option><option value="${"luxury"}">Luxury</option><option value="${"night"}">Night</option><option value="${"pastel"}">Pastel</option><option value="${"synthwave"}">Synthwave</option><option value="${"winter"}">Winter</option></select></div>`;
});
const Navbar = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $store, $$unsubscribe_store;
  $$unsubscribe_store = subscribe(store, (value) => $store = value);
  $$unsubscribe_store();
  return `<div class="${"navbar bg-primary"}"><div class="${"navbar-start"}"><div class="${"dropdown bg-primary"}">
			<label tabindex="${"0"}" class="${"btn btn-ghost lg:hidden w-55"}"><svg xmlns="${"http://www.w3.org/2000/svg"}" class="${"h-5 w-5"}" fill="${"none"}" viewBox="${"0 0 24 24"}" stroke="${"currentColor"}"><path stroke-linecap="${"round"}" stroke-linejoin="${"round"}" stroke-width="${"2"}" d="${"M4 6h16M4 12h8m-8 6h16"}"></path></svg></label>
			<ul tabindex="${"0"}" class="${"menu dropdown-content mt-4 p-5 shadow bg-primary text-primary-content rounded-box w-60"}"><li class="${"mx-auto"}"><a sveltekit:prefetch class="${"text-lg"}" href="${"/"}">Home</a></li>
				<li class="${"mx-auto"}"><a sveltekit:prefetch class="${"text-lg"}" href="${"/about"}">About</a></li>
				${$store != null ? `<li class="${"mx-auto"}"><a sveltekit:prefetch class="${"text-lg"}" href="${"/profile"}">${escape($store[0])}</a></li>
					<li class="${"mx-auto"}"><a class="${"text-lg"}" href="${"/"}">Logout</a></li>` : `<li class="${"mx-auto"}"><a sveltekit:prefetch class="${"text-lg"}" href="${"/login"}">Login</a></li>
					<li class="${"mx-auto"}"><a sveltekit:prefetch class="${"text-lg"}" href="${"/register"}">Signup</a></li>`}</ul></div>
		<a class="${"btn btn-ghost normal-case text-xl text-primary-content"}" sveltekit:prefetch href="${"/"}">Plantronics</a></div>
	<div class="${"navbar-center hidden lg:flex"}"><ul class="${"menu menu-horizontal p-0"}"><li><a sveltekit:prefetch href="${"/"}">Home</a></li>
			<li><a sveltekit:prefetch href="${"/about"}">About</a></li>
			${$store != null ? `<li><a sveltekit:prefetch href="${"/profile"}">${escape($store[0])}</a></li>
				<li><a href="${"/"}">Logout</a></li>` : `<li><a sveltekit:prefetch href="${"/login"}">Login</a></li>
				<li><a sveltekit:prefetch href="${"/register"}">Signup</a></li>`}</ul></div>
	<div class="${"navbar-end"}">${validate_component(Themeswitch, "ThemeSelect").$$render($$result, {}, {}, {})}</div></div>`;
});
var app = "";
const _layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${$$result.head += `<link rel="${"manifest"}" crossorigin="${"use-credentials"}" href="${"/manifest.json"}" data-svelte="svelte-qlfws3"><link rel="${"apple-touch-icon"}" href="${"/images/icons/icon-192x192.png"}" data-svelte="svelte-qlfws3"><link rel="${"icon"}" href="${"/favicon.png"}" data-svelte="svelte-qlfws3">`, ""}
${validate_component(Navbar, "NavBar").$$render($$result, {}, {}, {})}

<main class="${"w-100 break-words"}">${slots.default ? slots.default({}) : ``}</main>

<footer></footer>`;
});
export { _layout as default };
