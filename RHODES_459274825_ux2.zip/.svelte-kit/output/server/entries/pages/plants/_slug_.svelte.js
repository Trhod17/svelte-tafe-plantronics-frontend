import { c as create_ssr_component, a as subscribe, e as escape, v as validate_component, f as add_attribute } from "../../../chunks/index-de5ece87.js";
import { P as Planttab } from "../../../chunks/planttab-36ba882b.js";
import { s as store } from "../../../chunks/auth-68aeceae.js";
import "../../../chunks/index-fadab37b.js";
import "axios";
let slug;
async function load({ params }) {
  slug = params.slug;
  return params;
}
const U5Bslugu5D = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_store;
  $$unsubscribe_store = subscribe(store, (value) => value);
  let data = [];
  $$unsubscribe_store();
  return `${$$result.head += `${data != "" ? `${$$result.title = `<title>${escape(data.data.attributes.plant_name)}</title>`, ""}` : ``}`, ""}

<main lang="${"en"}">${validate_component(Planttab, "PlantTab").$$render($$result, { active: 0, slug }, {}, {})}
	<div class="${"p-3"}"></div>
	<div class="${"card border w-10/12 text-base-content ml-6 bg-primary-focus"}"><div class="${"card-body whitespace-pre-wrap text-sm break-words"}"><p class="${"card-title"}"></p>
			<ul>${data != "" ? `<li class="${"card-title"}">${escape(data.data.attributes.plant_name)}</li>
					<li>Latin Name: ${escape(data.data.attributes.plant_latin_name)}</li>
					<li>Family: ${escape(data.data.relationships.family.data.id)}</li>
					<li>Genus: ${escape(data.data.relationships.genus.data.id)}</li>
					<li><div tabindex="${"0"}" class="${"collapse collapse-arrow border border-base-300 bg-accent text-accent-content rounded-box"}"><input type="${"checkbox"}">
						<div class="${"collapse-title text-xl font-medium"}">Description</div>
						<div class="${"collapse-content"}"><p>${escape(data.data.attributes.plant_description)}</p></div></div></li>
					<li><img${add_attribute("src", data.data.attributes.plant_image, 0)}${add_attribute("alt", data.data.attributes.plant_name, 0)}></li>` : ``}</ul></div></div></main>`;
});
export { U5Bslugu5D as default, load, slug };
