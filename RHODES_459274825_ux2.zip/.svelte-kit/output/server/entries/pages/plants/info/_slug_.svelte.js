import { c as create_ssr_component, a as subscribe, e as escape, v as validate_component, d as each } from "../../../../chunks/index-de5ece87.js";
import { P as Planttab } from "../../../../chunks/planttab-36ba882b.js";
import { w as writable } from "../../../../chunks/index-fadab37b.js";
import { N as Nodata } from "../../../../chunks/nodata-4fe287a2.js";
let info = [];
let slug;
let data = writable(true);
async function load({ params }) {
  slug = params.slug;
  let headersList = {
    Accept: "*/*",
    "Content-Type": "application/api.vnd+json"
  };
  let bodyContent = JSON.stringify({ id: slug });
  return fetch("https://plantronics-backend.herokuapp.com/plantinfo/", {
    method: "POST",
    body: bodyContent,
    headers: headersList
  }).then(function(response) {
    if (response.status == 404) {
      data = writable(false);
    }
    return response.json();
  }).then(function(data2) {
    info = data2;
    return data2;
  });
}
const U5Bslugu5D = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let hasData;
  let num;
  let $data, $$unsubscribe_data;
  $$unsubscribe_data = subscribe(data, (value) => $data = value);
  hasData = $data;
  num = 1;
  $$unsubscribe_data();
  return `${$$result.head += `${info != "" && hasData ? `${$$result.title = `<title>${escape(info.info[0].plant__plant_name)}</title>`, ""}` : `${$$result.title = `<title>Has no data</title>`, ""}`}`, ""}

<main lang="${"en"}">${validate_component(Planttab, "PlantTab").$$render($$result, { active: 1, slug }, {}, {})}
	<div class="${"p-3"}"></div>
	<div class="${"card border w-10/12 text-base-content ml-6"}">${info != "" && hasData ? `<p class="${"card-title mx-auto"}">${escape(info.info[0].plant__plant_name)}</p>
			${each(info.info, (Info) => {
    return `<div class="${"card-body whitespace-pre-wrap text-sm break-words border items-center text-center"}"><p class="${"card-title"}">Info Set ${escape(num)}</p>
					<ul><li>Sun Preference: ${escape(Info.sun_preference)}</li>
						<li>Climate: ${escape(Info.climate)}</li>
						<li>Watering Schedule: ${escape(Info.time_frame)}</li>
						<li>Planting Season: ${escape(Info.season)}</li>
						<footer class="${"footer footer-center p-4 bg-primary-content text-base-content"}"><div><p>Info Card Created By: ${escape(Info.created_by__username)}</p></div>
						</footer></ul>
				</div>`;
  })}` : `${validate_component(Nodata, "NoData").$$render($$result, { page: "info" }, {}, {})}`}</div></main>`;
});
export { U5Bslugu5D as default, info, load };
