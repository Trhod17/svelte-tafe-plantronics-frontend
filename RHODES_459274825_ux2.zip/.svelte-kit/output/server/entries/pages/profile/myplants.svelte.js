import { c as create_ssr_component, a as subscribe, d as each, e as escape, v as validate_component } from "../../../chunks/index-de5ece87.js";
import { s as store } from "../../../chunks/auth-68aeceae.js";
import { P as Profiletab } from "../../../chunks/profiletab-268bc4c0.js";
import "../../../chunks/index-fadab37b.js";
import "axios";
const MyPlants = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_store;
  $$unsubscribe_store = subscribe(store, (value) => value);
  let { data = [] } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  $$unsubscribe_store();
  return `${data != "" ? `${each(data.userplants, (plant) => {
    return `<div class="${"card card-compact lg:card-side bg-success-content text-base-content shadow-xl"}"><div class="${"card-body"}"><h2 class="${"card-title"}">Plant: ${escape(plant.plant__plant_name)}</h2>
				<h2 class="${"card-title"}">Owned By: ${escape(plant.user__username)}</h2>
			</div></div>
		<div class="${"p-2"}"></div>`;
  })}` : ``}`;
});
const Myplants = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(Profiletab, "ProfileTab").$$render($$result, { active: 1 }, {}, {})}
${validate_component(MyPlants, "MyPlants").$$render($$result, {}, {}, {})}`;
});
export { Myplants as default };
