const build = [
  "/_app/start-5d1e778a.js",
  "/_app/pages/__layout.svelte-42289fa2.js",
  "/_app/assets/pages/__layout.svelte-4bcdb9f0.css",
  "/_app/error.svelte-69c52dad.js",
  "/_app/pages/about.svelte-620011da.js",
  "/_app/assets/pages/about.svelte-025f48ba.css",
  "/_app/pages/index.svelte-cb54d44d.js",
  "/_app/assets/pages/index.svelte-deb719a2.css",
  "/_app/pages/login.svelte-349d5370.js",
  "/_app/pages/plants/_slug_.svelte-1fd82e89.js",
  "/_app/pages/plants/edible/_slug_.svelte-e0cf5471.js",
  "/_app/pages/plants/info/_slug_.svelte-b6153b93.js",
  "/_app/pages/plants/soil/_slug_.svelte-ba5a2362.js",
  "/_app/pages/profile/myplants.svelte-4a62c183.js",
  "/_app/pages/profile.svelte-ce207852.js",
  "/_app/pages/register.svelte-3796e068.js",
  "/_app/chunks/index-4816ba6f.js",
  "/_app/chunks/index-79f0eb3b.js",
  "/_app/chunks/auth-ba37ac4d.js",
  "/_app/chunks/index-a44f789b.js",
  "/_app/chunks/planttab-5ea4695d.js",
  "/_app/chunks/nodata-32a151d6.js",
  "/_app/chunks/profiletab-fb2efa12.js"
];
const files = [
  "/favicon.png",
  "/icon512.png",
  "/images/icons/icon-128x128.png",
  "/images/icons/icon-144x144.png",
  "/images/icons/icon-152x152.png",
  "/images/icons/icon-192x192.png",
  "/images/icons/icon-384x384.png",
  "/images/icons/icon-512x512.png",
  "/images/icons/icon-72x72.png",
  "/images/icons/icon-96x96.png",
  "/manifest.json",
  "/robots.txt",
  "/svelte-welcome.png",
  "/svelte-welcome.webp"
];
const version = "1652413889471";
const worker = self;
const FILES = `cache${version}`;
const to_cache = build.concat(files);
const staticAssets = new Set(to_cache);
worker.addEventListener("install", (event) => {
  event.waitUntil(caches.open(FILES).then((cache) => cache.addAll(to_cache)).then(() => {
    worker.skipWaiting();
  }));
});
worker.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then(async (keys) => {
    for (const key of keys) {
      if (key !== FILES)
        await caches.delete(key);
    }
    worker.clients.claim();
  }));
});
async function fetchAndCache(request) {
  const cache = await caches.open(`offline${version}`);
  try {
    const response = await fetch(request);
    cache.put(request, response.clone());
    return response;
  } catch (err) {
    const response = await cache.match(request);
    if (response)
      return response;
    throw err;
  }
}
worker.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET" || event.request.headers.has("range"))
    return;
  const url = new URL(event.request.url);
  const isHttp = url.protocol.startsWith("http");
  const isDevServerRequest = url.hostname === self.location.hostname && url.port !== self.location.port;
  const isStaticAsset = url.host === self.location.host && staticAssets.has(url.pathname);
  const skipBecauseUncached = event.request.cache === "only-if-cached" && !isStaticAsset;
  if (isHttp && !isDevServerRequest && !skipBecauseUncached) {
    event.respondWith((async () => {
      const cachedAsset = isStaticAsset && await caches.match(event.request);
      return cachedAsset || fetchAndCache(event.request);
    })());
  }
});
