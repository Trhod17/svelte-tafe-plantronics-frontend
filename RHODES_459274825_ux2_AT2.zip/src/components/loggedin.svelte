<script>
	import { store } from '../hooks/auth';
</script>

<main>
	{$store[0]} is logged in.
</main>
