import { c as create_ssr_component } from "../../chunks/index-de5ece87.js";
const browser = false;
const dev = false;
var about_svelte_svelte_type_style_lang = "";
const css = {
  code: "main.svelte-du1ydg{font-size:1.5rem;margin:4rem;padding:2rem;color:gray;justify-content:center;box-shadow:4px 5px 11px 10px lightgray}",
  map: null
};
const hydrate = dev;
const router = browser;
const prerender = true;
const About = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<main class="${"svelte-du1ydg"}"><h1>ABOUT</h1>
	<hr>
	<div>A website aimed to help people learn about and manage their plants</div>
</main>`;
});
export { About as default, hydrate, prerender, router };
