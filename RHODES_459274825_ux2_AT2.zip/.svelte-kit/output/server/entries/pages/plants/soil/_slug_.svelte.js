import { c as create_ssr_component, a as subscribe, e as escape, v as validate_component, d as each } from "../../../../chunks/index-de5ece87.js";
import { w as writable } from "../../../../chunks/index-fadab37b.js";
import { P as Planttab } from "../../../../chunks/planttab-36ba882b.js";
import { N as Nodata } from "../../../../chunks/nodata-4fe287a2.js";
let soil = [];
let slug;
let data = writable(true);
async function load({ params }) {
  slug = params.slug;
  let headersList = {
    Accept: "*/*",
    "Content-Type": "application/api.vnd+json"
  };
  let bodyContent = JSON.stringify({ id: slug });
  return fetch("https://plantronics-backend.herokuapp.com/plantsoil/", {
    method: "POST",
    body: bodyContent,
    headers: headersList
  }).then(function(response) {
    if (response.status == 404) {
      data = writable(false);
    }
    return response.json();
  }).then(function(data2) {
    soil = data2;
    return data2;
  });
}
const U5Bslugu5D = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let hasData;
  let num;
  let $data, $$unsubscribe_data;
  $$unsubscribe_data = subscribe(data, (value) => $data = value);
  hasData = $data;
  num = 1;
  $$unsubscribe_data();
  return `${$$result.head += `${soil != "" && hasData ? `${$$result.title = `<title>${escape(soil.soil[0].plants__plant_name)}</title>`, ""}` : `${$$result.title = `<title>Has no data</title>`, ""}`}`, ""}

<main lang="${"en"}">${validate_component(Planttab, "PlantTab").$$render($$result, { active: 2, slug }, {}, {})}
	<div class="${"p-3"}"></div>
	<div class="${"card border w-10/12 text-base-content ml-6"}">${soil != "" && hasData ? `<p class="${"card-title mx-auto"}">${escape(soil.soil[0].plants__plant_name)}</p>
			${each(soil.soil, (Soil) => {
    return `<div class="${"card-body whitespace-pre-wrap text-sm break-words border items-center text-center"}"><p class="${"card-title"}">Soil Set ${escape(num)}</p>
					<ul><li>Soil Preference: ${escape(Soil.preference)}</li>
						<li>Preference Description: ${escape(Soil.soil_description)}</li>
						<footer class="${"footer footer-center p-4 bg-primary-content text-base-content"}"><div><p>Soil Card Created By: ${escape(Soil.created_by__username)}</p></div>
						</footer></ul>
				</div>`;
  })}` : `${validate_component(Nodata, "NoData").$$render($$result, { page: "soil preference data" }, {}, {})}`}</div></main>`;
});
export { U5Bslugu5D as default, load, soil };
