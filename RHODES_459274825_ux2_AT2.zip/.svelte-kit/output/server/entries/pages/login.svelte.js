import { c as create_ssr_component, a as subscribe, f as add_attribute, e as escape, v as validate_component } from "../../chunks/index-de5ece87.js";
import { s as store } from "../../chunks/auth-68aeceae.js";
import * as yup from "yup";
import YupPassword from "yup-password";
import reporter from "@felte/reporter-tippy";
import { validator } from "@felte/validator-yup";
import { c as createForm } from "../../chunks/create-form-80011629.js";
import "../../chunks/index-fadab37b.js";
import "axios";
const Login$1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let loginMessage;
  let $$unsubscribe_store;
  let $data, $$unsubscribe_data;
  $$unsubscribe_store = subscribe(store, (value) => value);
  YupPassword(yup);
  const schema = yup.object({
    account: yup.object({
      username: yup.string().required(),
      password: yup.string().required()
    })
  });
  const { form, data, unsetField, addField } = createForm({
    initialValues: {
      account: { username: "", password: "" },
      extras: { tags: [{ value: "" }] }
    },
    onSubmit(values) {
    },
    extend: [validator({ schema }), reporter()]
  });
  $$unsubscribe_data = subscribe(data, (value) => $data = value);
  loginMessage = "";
  $$unsubscribe_store();
  $$unsubscribe_data();
  return `${$$result.head += `${$$result.title = `<title>Login</title>`, ""}<meta name="${"description"}" content="${"Plantronics Login Page"}" data-svelte="svelte-4b436o"><script src="${"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"}" integrity="${"sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"}" crossorigin="${"anonymous"}" data-svelte="svelte-4b436o"><\/script>`, ""}

<form class="${"ml-5 w-3/4"}"><div class="${"p-2"}"></div>
	<div class="${"form-control w-full max-w-xs"}"><label class="${"label"}" for="${"username"}"><span class="${"label-text"}">Username:</span></label>
		<input type="${"text"}" placeholder="${"Username"}" name="${"username"}" id="${"username"}" class="${"input input-bordered w-full max-w-xs"}" required autocomplete="${"username"}"${add_attribute("value", $data.account.username, 0)}></div>
	<div class="${"p-2"}"></div>
	<div class="${"form-control w-full max-w-xs"}"><label class="${"label"}" for="${"password"}"><span class="${"label-text"}">Password:</span></label>
		<input type="${"password"}" placeholder="${"Password"}" name="${"password2"}" id="${"password2"}" class="${"input input-bordered w-full max-w-xs"}" autocomplete="${"current=password"}"${add_attribute("value", $data.account.password, 0)}></div>
	<div>${escape(loginMessage)}</div>
	<div class="${"p-2"}"></div>
	<input type="${"submit"}" value="${"Login"}" class="${"btn btn-accent w-50 "}">
</form>`;
});
const Loggedin = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $store, $$unsubscribe_store;
  $$unsubscribe_store = subscribe(store, (value) => $store = value);
  $$unsubscribe_store();
  return `<main>${escape($store[0])} is logged in.
</main>`;
});
const prerender = true;
const Login = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $store, $$unsubscribe_store;
  $$unsubscribe_store = subscribe(store, (value) => $store = value);
  $$unsubscribe_store();
  return `${$$result.head += `${$$result.title = `<title>Login</title>`, ""}<meta name="${"description"}" content="${"Plantronics Login Page"}" data-svelte="svelte-1whxlw3">`, ""}

${$store != null ? `${validate_component(Loggedin, "AfterLogin").$$render($$result, {}, {}, {})}` : `${validate_component(Login$1, "LoginComponent").$$render($$result, {}, {}, {})}`}
`;
});
export { Login as default, prerender };
