import { w as writable } from "./index-fadab37b.js";
import "axios";
const store = writable(null);
export { store as s };
