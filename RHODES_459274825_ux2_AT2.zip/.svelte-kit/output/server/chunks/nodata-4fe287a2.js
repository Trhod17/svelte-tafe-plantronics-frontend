import { c as create_ssr_component, e as escape } from "./index-de5ece87.js";
const Nodata = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { page } = $$props;
  if ($$props.page === void 0 && $$bindings.page && page !== void 0)
    $$bindings.page(page);
  return `<main lang="${"en"}"><p class="${"card-title"}">This plant has no ${escape(page)}</p></main>`;
});
export { Nodata as N };
