import * as module from '../entries/pages/about.svelte.js';

export { module };
export const entry = 'pages/about.svelte-620011da.js';
export const js = ["pages/about.svelte-620011da.js","chunks/index-4816ba6f.js"];
export const css = ["assets/pages/about.svelte-025f48ba.css"];
