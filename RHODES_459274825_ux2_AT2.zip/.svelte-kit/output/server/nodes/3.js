import * as module from '../entries/pages/index.svelte.js';

export { module };
export const entry = 'pages/index.svelte-cb54d44d.js';
export const js = ["pages/index.svelte-cb54d44d.js","chunks/index-4816ba6f.js","chunks/auth-ba37ac4d.js","chunks/index-79f0eb3b.js"];
export const css = ["assets/pages/index.svelte-deb719a2.css"];
