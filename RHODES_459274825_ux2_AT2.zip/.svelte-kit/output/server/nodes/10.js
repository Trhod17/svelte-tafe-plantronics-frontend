import * as module from '../entries/pages/profile.svelte.js';

export { module };
export const entry = 'pages/profile.svelte-ce207852.js';
export const js = ["pages/profile.svelte-ce207852.js","chunks/index-4816ba6f.js","chunks/auth-ba37ac4d.js","chunks/index-79f0eb3b.js","chunks/profiletab-fb2efa12.js"];
export const css = [];
