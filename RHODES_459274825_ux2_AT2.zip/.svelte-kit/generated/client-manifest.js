export { matchers } from './client-matchers.js';

export const components = [
	() => import("../../src/routes/__layout.svelte"),
	() => import("../runtime/components/error.svelte"),
	() => import("../../src/routes/about.svelte"),
	() => import("../../src/routes/index.svelte"),
	() => import("../../src/routes/login.svelte"),
	() => import("../../src/routes/plants/[slug].svelte"),
	() => import("../../src/routes/plants/edible/[slug].svelte"),
	() => import("../../src/routes/plants/info/[slug].svelte"),
	() => import("../../src/routes/plants/soil/[slug].svelte"),
	() => import("../../src/routes/profile/myplants.svelte"),
	() => import("../../src/routes/profile.svelte"),
	() => import("../../src/routes/register.svelte")
];

export const dictionary = {
	"": [[0, 3], [1]],
	"about": [[0, 2], [1]],
	"login": [[0, 4], [1]],
	"profile": [[0, 10], [1]],
	"register": [[0, 11], [1]],
	"profile/myplants": [[0, 9], [1]],
	"plants/edible/[slug]": [[0, 6], [1]],
	"plants/info/[slug]": [[0, 7], [1]],
	"plants/soil/[slug]": [[0, 8], [1]],
	"plants/[slug]": [[0, 5], [1]]
};